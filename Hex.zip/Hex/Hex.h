#pragma once

class Hex {
public:
	sf::CircleShape hexagon;
	float x;
	float y;
	int row;
	int col;
	bool clicked = false;
	bool outer = false;
};