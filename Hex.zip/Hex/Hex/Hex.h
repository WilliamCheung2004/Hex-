#pragma once

class Hex {
public:
	sf::CircleShape shape;
	float x;
	float y;
	bool clicked = false;
};