#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Window/Event.hpp>
#include <iostream>
#include <optional>
#include <string>
#include <cmath>
#include "Hex.h"

using namespace std;
using namespace sf;

int screenX = sf::VideoMode::getDesktopMode().size.x;
int screenY = sf::VideoMode::getDesktopMode().size.y;

float x;
float y;

int rows = 5;
int cols = 5;

int originalCols;
int originalRows;

float hexWidth = 30.f;
float hexHeight = sqrt(3) / 2 * hexWidth;

bool drawn = false;
bool ran = false;

int player = 1;

vector<Hex> hexes;
vector<vector<int>> board(rows, vector<int>(cols, 0));

int main() {

	originalCols = cols;
	originalRows = rows;

	sf::RenderWindow window(
		sf::VideoMode::getDesktopMode(),
		"Hex Game",
		sf::Style::Default,
		sf::State::Fullscreen
	);

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {

			if ((i == 0 || i == rows - 1) && (j == 0 || j == cols - 1)) {
				board[i][j] = 0;
			}
			else if (i == 0 || i == rows - 1) {
				board[i][j] = 1;
			}
			else if (j == 0 || j == cols - 1) {
				board[i][j] = 2;
			}
			else {
				board[i][j] = 0;
			}
		}
	}

	while (window.isOpen()) {
		while (const std::optional event = window.pollEvent()) {
			if (event->is<sf::Event::Closed>())
				window.close();
		}

		window.clear(sf::Color::Black);

		if (!drawn) {

			float startX = screenX * 0.35f;
			float startY = screenY * 0.25f;

			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {

					if (board[i][j] == 0 && (i == 0 || i == rows - 1) && (j == 0 || j == cols - 1))
						continue;

					sf::CircleShape hexagon(hexWidth, 6);

					x = startX + j * (hexWidth * 2.0f) + (i * hexWidth * 0.9f);
					y = startY + i * (hexHeight * 2.0f);

					Hex hex;

					if (board[i][j] == 1) {
						hex.outer = true;
						hexagon.setFillColor(sf::Color::Red);
					}
					else if (board[i][j] == 2) {
						hex.outer = true;
						hexagon.setFillColor(sf::Color::Blue);
					}
					else {
						hex.outer = false;
						hexagon.setFillColor(sf::Color::White);
					}

					hex.x = x;
					hex.y = y;
					hex.row = i;
					hex.col = j;
					hexagon.setPosition({ x, y });
					hex.hexagon = hexagon;
					hexes.push_back(hex);
				}
			}

			drawn = true;
		}


		for (int i = 0; i < hexes.size(); i++) {
			hexes[i].hexagon.setPosition({ hexes[i].x, hexes[i].y });
			window.draw(hexes[i].hexagon);
		}

		for (int i = 0; i < hexes.size(); i++) {
			if (hexes[i].hexagon.getGlobalBounds().contains(static_cast<sf::Vector2f>(sf::Mouse::getPosition(window))) && sf::Mouse::isButtonPressed(sf::Mouse::Button::Left)) {

				if (!hexes[i].clicked && !hexes[i].outer) {
					if (player == 1) {
						hexes[i].hexagon.setFillColor(sf::Color::Red);
						player = 2;
						hexes[i].clicked = true;
					}
					else {
						hexes[i].hexagon.setFillColor(sf::Color::Blue);
						player = 1;
						hexes[i].clicked = true;
					}
				}
			}
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Escape)) {
			window.close();
			return 0;
		}

		if (!ran) {
			cout << ("Hexes in board state:") << endl;
			cout << "---------------------" << endl;
			for (int i = 0; i < board.size(); i++) {
				for (int j = 0; j < board[i].size(); j++) {
					cout << board[i][j] << " ";
				}
				cout << endl;
			}
			cout << "---------------------" << endl;
			ran = true;
		}

		window.display();
	}

	return 0;
}
